if( typeof Prototype=='undefined' ){
  document.write(' <script type="text/javascript" src="'+SidebarItemCollapseConfiguration.PluginPath+'/js/prototype.js"></script>');
}
if( typeof Scriptaculous=='undefined' ){
  document.write(' <script type="text/javascript" src="'+SidebarItemCollapseConfiguration.PluginPath+'/js/scriptaculous.js"></script>');
}

document.write(' <script type="text/javascript" src="'+SidebarItemCollapseConfiguration.PluginPath+'/js/common.js"></script>');
document.write(' <script type="text/javascript" src="'+SidebarItemCollapseConfiguration.PluginPath+'/js/domready.js"></script>');
document.write(' <script type="text/javascript" src="'+SidebarItemCollapseConfiguration.PluginPath+'/js/sidebaritemcollapse.js"></script>');
