/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'ko', {
	anchor: '책갈피',
	flash: '플래시 애니메이션',
	hiddenfield: '숨은 입력 칸',
	iframe: '아이프레임',
	unknown: '알 수 없는 객체'
} );
