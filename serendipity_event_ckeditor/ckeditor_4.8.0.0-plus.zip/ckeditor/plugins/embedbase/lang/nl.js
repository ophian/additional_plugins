/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'nl', {
	pathName: 'media object',
	title: 'Mediareferentie',
	button: 'Mediareferentie invoegen',
	unsupportedUrlGiven: 'De opgegeven URL wordt niet ondersteund.',
	unsupportedUrl: 'De URL {url} wordt niet ondersteund door Mediareferentie.',
	fetchingFailedGiven: 'Kon de inhoud van de opgegeven URL niet ophalen',
	fetchingFailed: 'Kon de inhoud van {url} niet ophalen.',
	fetchingOne: 'Ophalen van oEmbed antwoord…',
	fetchingMany: 'Ophalen van oEmbed antwoorden, {current} van {max} klaar…'
} );
