/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'uk', {
	pathName: 'Медіаоб’єкт',
	title: 'Медіаконтент',
	button: 'Вставити медіаконтент',
	unsupportedUrlGiven: 'Вказане URL посилання не підтримується.',
	unsupportedUrl: 'URL посилання {url} не підтримується медіаконтентом.',
	fetchingFailedGiven: 'Не вдалося отримати контент для даного URL посилання.',
	fetchingFailed: 'Не вдалося отримати контент для {url}.',
	fetchingOne: 'Отримання oEmbed відповіді...',
	fetchingMany: 'Отримання {current} із {max} oEmbed відповідей завершено....'
} );
