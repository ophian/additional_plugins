/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'zh', {
	anchor: '錨點',
	flash: 'Flash 動畫',
	hiddenfield: '隱藏欄位',
	iframe: 'IFrame',
	unknown: '無法辨識的物件'
} );
