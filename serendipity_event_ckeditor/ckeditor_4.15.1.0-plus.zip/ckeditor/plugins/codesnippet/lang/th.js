/**
 * @license Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.plugins.setLang( 'codesnippet', 'th', {
	button: 'แทรกชิ้นส่วนของรหัสหรือโค้ด',
	codeContents: 'Code content', // MISSING
	emptySnippetError: 'A code snippet cannot be empty.', // MISSING
	language: 'Language', // MISSING
	title: 'Code snippet', // MISSING
	pathName: 'code snippet' // MISSING
} );
