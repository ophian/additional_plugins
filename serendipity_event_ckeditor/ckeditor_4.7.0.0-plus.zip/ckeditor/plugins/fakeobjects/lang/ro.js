/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'ro', {
	anchor: 'Inserează/Editează ancoră',
	flash: 'Flash Animation', // MISSING
	hiddenfield: 'Câmp ascuns (HiddenField)',
	iframe: 'IFrame', // MISSING
	unknown: 'Unknown Object' // MISSING
} );
